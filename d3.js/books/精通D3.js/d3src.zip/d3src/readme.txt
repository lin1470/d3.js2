﻿源代码的使用方法：

1.下载 d3src.zip，解压缩，得到一个文件夹 d3src。

2. 安装一个服务器软件，例如 Apache、Tomcat、IIS 等。如果不会，可以参考 OUR D3.JS 的文章【搭建 Apache】，网址如下：

http://www.ourd3js.com/wordpress/?p=413

3. 将文件夹 d3src 拷贝到服务器根目录下。

4. 打开浏览器，输入：http://127.0.0.1/d3src/index.html ，即可。

注意：建议使用谷歌浏览器，从目前的试验来看，谷歌浏览器对 D3.js 的支持是最完美的。